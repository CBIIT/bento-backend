import json
import re
import os
import boto3
import urllib3

slack_url = os.getenv("SLACK_URL")
slack_channel = os.getenv("SLACK_CHANNEL")


http = urllib3.PoolManager()
def handler(event, context):
    url = slack_url
    msg = {
        "channel": slack_channel,
        "text": event['Records'][0]['Sns']['Message'],
        "icon_emoji": ":alert:"
    }

    msg = json.dumps(msg).encode('utf-8')
    resp = http.request('POST',url, body=msg)
    print({
        "message": event['Records'][0]['Sns']['Message'],
        "status_code": resp.status,
        "response": resp.data
    })
